%% start
clear
clc;
addpath(genpath(cd));
addpath(genpath('data'));
addpath(genpath('ToolBox'));
%% choose the data
 key = 'abu-urban-5';
% key = 'HYDICE_urban';
% key = 'abu-beach-1(cat-island)';
% key = 'abu-airport-2(los-angeles-1)';
% key = 'abu-beach-4(pavia)';
% key='abu-airport-4(gulfport)';
% key='cri';
% key='Segundo';
% key='Belcher';


%% load data & data process
disp(key)
input=[key,'.mat'];
hsi=load(input);
DataTest = hsi.data;
mask = double(hsi.map);
[H,W,~]=size(DataTest);
num=H*W;
mask_reshape = reshape(mask, 1, num);
anomaly_map = logical(double(mask_reshape)>0);                                                                                                                                                                                                        
normal_map = logical(double(mask_reshape)==0);
opts=[];

[H,W,Dim]=size(DataTest);
num=H*W;
for i=1:Dim 
    DataTest(:,:,i) = (DataTest(:,:,i)-min(min(DataTest(:,:,i)))) / (max(max(DataTest(:,:,i))-min(min(DataTest(:,:,i)))));
end 

Y=reshape(DataTest, num, Dim)';
X=DataTest;  
[n1,n2,n3]=size(X);

% %% ==========================Contrast Experiment==============================
% %% MNTNN-SET parameters
opts = get_parameter(key);
opts.anomaly_map=anomaly_map;
opts.normal_map=normal_map;

%% MNTNN-Running 
 disp('Running MNTNN��Please wait...')
 tic
  [A,tlrr_E,Out] = HAD_MNTNN(X,opts);
 ttime=toc;
%% Compute Auc
 disp('Computing AUC��Please wait...')
E = sqrt(sum(tlrr_E.^2,3));

E = (E-min(E(:))) /(max(E(:))-min(E(:)));
imshow(E,[]);colormap jet;
r_new= E(:)';
[AUC,~] = cal_AUC(r_new',mask_reshape',1,1 );
AUC_vector = struct2array(AUC);
AUC_vector = AUC_vector(:);
%% Output
     
fprintf('--------------------------------\n'); 
fprintf('%-15s : %s\n',   'Data',        key);
fprintf('%-15s : %.4f\n', 'AUC_(D,F)',   AUC_vector(1));
fprintf('%-15s : %.4f\n', 'AUC_(D,tau)', AUC_vector(2));
fprintf('%-15s : %.4f\n', 'AUC_(F,tau)', AUC_vector(3));
fprintf('%-15s : %.4f s\n','Time',       ttime);

fprintf('--------------------------------\n');


