function [A,E,OUT] = had_MNTNN(Observe,opts)

if isfield(opts, 'tol');        tol         =  opts.tol;         end
if isfield(opts, 'max_iter');   max_iter    =  opts.max_iter;	 end
if isfield(opts, 'inner');      inner       =  opts.inner;       end
if isfield(opts, 'rho');         rho          =  opts.rho;          end
if isfield(opts, 'rank3');           rank3          =  opts.rank3;      end
if isfield(opts, 'rank2');           rank2          =  opts.rank2;      end
if isfield(opts, 'rank1');           rank1         =  opts.rank1;      end
if isfield(opts, 'p1');           p1          =  opts.p1;          end
if isfield(opts, 'p2');           p2          =  opts.p2;          end
if isfield(opts, 'p3');           p3          =  opts.p3;          end
if isfield(opts, 'm1');           m1          =  opts.m1;          end
if isfield(opts, 'm2');           m2          =  opts.m2;          end
if isfield(opts, 'm3');           m3          =  opts.m3;          end
if isfield(opts, 'maxrho');           maxrho          =  opts.maxrho;  end
if isfield(opts, 'beta');           beta          =  opts.beta;  end
if isfield(opts, 'q'); q=opts.q; end
if isfield(opts, 'a1'); a1=opts.a1; end
if isfield(opts, 'a2'); a2=opts.a2; end
if isfield(opts, 'a3'); a3=opts.a3; end
AUC_maxiter=0;
iter_AUCmaxiter=0;
%% initialization
%X=A
A   = Observe;
%Tu
[D01,~,~] = svds(Unfold(A, size(A), 1),rank1);
Tu1   = D01';
[D02,~,~] = svds(Unfold(A, size(A), 2),rank2);
Tu2   = D02';
[D03,~,~] = svds(Unfold(A, size(A), 3),rank3);
Tu3   = D03';
%Z
Z1 = tmprod(A, Tu1, 1);
Z2 = tmprod(A, Tu2, 2);
Z3 = tmprod(A, Tu3, 3);
%Y
Y1 = tanh(Z1);
Y2 = tanh(Z2);
Y3 = tanh(Z3);

E=zeros(size(A));

%Lagrange multipliers
Q=zeros(size(A));
P1=zeros(size(A));
P2=zeros(size(A));
P3=zeros(size(A));
M1=zeros(size(Y1));
M2=zeros(size(Y2));
M3=zeros(size(Y3));


OUT  = []; 
%% ADMM
for iter = 1 : max_iter
    A_pre = A;
    Y1_pre = Y1; Y2_pre = Y2;  Y3_pre = Y3;
    Z1_pre = Z1;Z2_pre = Z2; Z3_pre = Z3;
    Tu1_pre = Tu1;Tu2_pre = Tu2;Tu3_pre = Tu3;
    E_pre=E;
    %% update A=X
    N0=Observe-E+Q/q;
    N1= tmprod(Z1, Tu1', 1)- P1/p1;
    N2= tmprod(Z2, Tu2', 2)- P2/p2;
    N3= tmprod(Z3, Tu3', 3)- P3/p3;
    A=(q*N0+p1*N1+p2*N2+p3*N3)/(q+p1+p2+p3);
    
    %% update Y
    %Y1
    Y1_permute1     = my_SVD( tanh(permute(Z1,[2,3,1]))-permute(M1,[2,3,1])/m1 , a1/m1 );
    Y1=ipermute(Y1_permute1,[2,3,1]);
    %Y2
    Y2_permute2     = my_SVD( tanh(permute(Z2,[3,1,2]))-permute(M2,[3,1,2])/m2 , a2/m2 );
    Y2=ipermute(Y2_permute2,[3,1,2]);
    %Y3
    Y3     = my_SVD( tanh(Z3)-M3/m3 , a3/m3 );
    %% update Z
    %Z1
    Z1_mat1   =Unfold(Z1,size(Z1),1);
    z1temp1  = Unfold(Y1+M1/m1,size(Y1),1);
    
    z1temp2=Tu1 * Unfold(A+P1/p1,size(A),1);
    Z1_mat1  = Newton(z1temp1,z1temp2,Z1_mat1,inner,p1,m1);
    Z1      = Fold(Z1_mat1,size(Z1),1);
    %Z2
    Z2_mat2   =Unfold(Z2,size(Z2),2);
    z2temp1  = Unfold(Y2+M2/m2,size(Y2),2);
    
    z2temp2=Tu2 * Unfold(A+P2/p2,size(A),2);%G
    Z2_mat2  = Newton(z2temp1,z2temp2,Z2_mat2,inner,p2,m2);
    Z2      = Fold(Z2_mat2,size(Z2),2);
    %Z3
    Z3_mat3   =Unfold(Z3,size(Z3),3);
    z3temp1  = Unfold(Y3+M3/m3,size(Y3),3);
    
    z3temp2=Tu3 * Unfold(A+P3/p3,size(A),3);
    Z3_mat3  = Newton(z3temp1,z3temp2,Z3_mat3,inner,p3,m3);
    Z3      = Fold(Z3_mat3,size(Z3),3);
    %% update Tu
    %Tu1
    A_mat1   =Unfold(A+P1/p1,size(A),1);
    Z1_mat1   =Unfold(Z1,size(Z1),1);
    Ttemp1 =  p1* A_mat1 * Z1_mat1';
    Ttemp1(isnan(Ttemp1)) = 0; Ttemp1(isinf(Ttemp1)) = 0;
    [U1,~,V1] = svd( Ttemp1 , 'econ');
    Tu1   = V1 * U1';
    %Tu2
    A_mat2   =Unfold(A+P2/p2,size(A),2);
    Z2_mat2   =Unfold(Z2,size(Z2),2);
    Ttemp2 =  p2* A_mat2 * Z2_mat2';
    Ttemp2(isnan(Ttemp2)) = 0; Ttemp2(isinf(Ttemp2)) = 0;
    [U2,~,V2] = svd( Ttemp2 , 'econ');
    Tu2   = V2 * U2';
    %Tu3
    A_mat3   =Unfold(A+P3/p3,size(A),3);
    Z3_mat3   =Unfold(Z3,size(Z3),3);
    Ttemp3 =  p3* A_mat3 * Z3_mat3';
    Ttemp3(isnan(Ttemp3)) = 0; Ttemp3(isinf(Ttemp3)) = 0;
    [U3,~,V3] = svd( Ttemp3 , 'econ');
    Tu3   = V3 * U3';
    %% update E
    R2=Observe-A+Q/q;
    E = solve_l1l1l2( R2, beta/q );
    %% check convergence
    leq1 = Observe-A-E;
    leq2 = A-tmprod(Z1,Tu1',1); leq3 = A-tmprod(Z2,Tu2',2); leq4 = A-tmprod(Z3,Tu3',3);
    leq5=Y1-tanh(Z1);leq6=Y2-tanh(Z2); leq7=Y3-tanh(Z3);
    
    % leqm1 = max(abs(leq1(:)));
    % leqm2 = max(abs(leq2(:)));leqm3 = max(abs(leq3(:)));leqm4 = max(abs(leq4(:)));
    % leqm5 = max(abs(leq5(:)));leqm6 = max(abs(leq6(:)));leqm7 = max(abs(leq7(:)));
    % 
    % difX = max(abs(A(:)-A_pre(:)));
    % difE = max(abs(E(:)-E_pre(:)));
    % difZ1 = max(abs(Z1(:)-Z1_pre(:)));difZ2 = max(abs(Z2(:)-Z2_pre(:)));difZ3 = max(abs(Z3(:)-Z3_pre(:)));
    % difTu1=max(abs(Tu1(:)-Tu1_pre(:))); difTu2=max(abs(Tu2(:)-Tu2_pre(:))); difTu3=max(abs(Tu3(:)-Tu3_pre(:)));
    % difY1 = max(abs(Y1(:)-Y1_pre(:))); difY2 = max(abs(Y2(:)-Y2_pre(:))); difY3 = max(abs(Y3(:)-Y3_pre(:)));
    % chgX    = norm(A_pre(:)-A(:))/norm(A_pre(:));
    % 
    % err1=leqm1;
    % err2=chgX;
    % err3= max([leqm1,leqm2,leqm3,leqm4,leqm5,leqm6,leqm7,difX,difZ1,difZ2,difZ3,difE,difTu1,difTu2,difTu3,difY1,difY2,difY3]);
    % err= max([err1,err2,err3]);
    

    % if  iter==1 || mod(iter,2) == 0
    %     sparsity=length(find(E~=0));
    % 
    %     auc=my_AUC(E,opts.normal_map,opts.anomaly_map);
    %     fprintf('MNTNN:  iter = %d   AUC_MNTNN=%f  err=%f  sparsity=%d    err1=%f  err2=%f  err3=%f \n', iter, auc*100,err,sparsity,err1,err2,err3);
    % 
    % end

    % if err < tol
    %     break;
    % 
    % end
    %% update Lagrange multiplier and  penalty parameter beta
    Q = Q + q*leq1;
    P1 = P1 + p1*leq2;P2 = P2 + p2*leq3;P3 = P3 + p3*leq4;
    M1 = M1 + m1*leq5;M2 = M2 + m2*leq6;M3 = M3 + m3*leq7;
    q= min(q*rho,maxrho);
    p1= min(p1*rho,maxrho); p2= min(p2*rho,maxrho); p3= min(p3*rho,maxrho);
    m1= min(m1*rho,maxrho); m2= min(m2*rho,maxrho); m3= min(m3*rho,maxrho);
    
end
% OUT.A = A; OUT.E = E;OUT.err = err;OUT.iter=iter;OUT.iter_AUCmaxiter=iter_AUCmaxiter;OUT.AUC_maxiter=AUC_maxiter;
end







%% nested functions
function Z  = Newton(g,a,Z,inner,alpha, beta)%Y,G,Z,INNER����ʼZ�ȽϹؼ�
i=0;
relchg=1;
tol=1e-4;
while  i < inner  &&  relchg > tol
    Zp=Z;
    Numer = beta .* (1 - tanh(Z).^2) .* (tanh(Z) - g) + alpha .* (Z - a);%һ�׵�
    Denom = -2 .* beta .* tanh(Z) .* ( 1 - tanh(Z).^2) .* (tanh(Z) - g) + beta .* ( 1 - tanh(Z).^2).^2 + alpha;%���׵�
    Z  = Z - Numer./Denom;
    relchg = norm(Z - Zp,'fro')/norm(Z,'fro');
    i=i+1;
end
end

function Y = my_SVD(Y,rho)
[n1, n2, n3] = size(Y);
n12 = min(n1, n2);
Uf = zeros(n1, n12, n3);
Vf = zeros(n2, n12, n3);
Sf = zeros(n12,n12, n3);
trank = 0;
Y(isnan(Y)) = 0;
Y(isinf(Y)) = 0;
for i = 1 : n3
    [Uf(:,:,i), Sf(:,:,i), Vf(:,:,i)] = svd(Y(:,:,i), 'econ');
    s = diag(Sf(:, :, i));
    s = max(s - rho, 0);
    Sf(:, :, i) = diag(s);
    temp = length(find(s>0));
    trank = max(temp, trank);
    Y(:,:,i) = Uf(:,:,i)*Sf(:,:,i)*Vf(:,:,i)';
end
end
function output = tanh(x)
output =(exp(x) - exp(-x))./(exp(x) + exp(-x));
end

function area=my_AUC(tlrr_E,normal_map,anomaly_map)
%% vis and Auc
[H,W,Dim]=size(tlrr_E);
num=H*W;
E=reshape(tlrr_E, num, Dim)';
r_new=sqrt(sum(E.^2,1));
r_max = max(r_new(:));
taus = linspace(0, r_max, 5000);
PF=zeros(1,5000);
PD=zeros(1,5000);
for index2 = 1:length(taus)
    tau = taus(index2);
    anomaly_map_rx = (r_new> tau);
    PF(index2) = sum(anomaly_map_rx & normal_map)/sum(normal_map);
    PD(index2) = sum(anomaly_map_rx & anomaly_map)/sum(anomaly_map);
end
area=sum((PF(1:end-1)-PF(2:end)).*(PD(2:end)+PD(1:end-1))/2);
end

   
